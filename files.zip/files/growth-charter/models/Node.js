const mongoose = require('mongoose');

const nodeSchema = new mongoose.Schema(
  {
    accountId: { type: mongoose.Schema.Types.ObjectId, ref: 'Account', required: true },
    nodeId:    { type: String, required: true },   // e.g. 'D1', 'I3'
    name:      { type: String, required: true },   // human-readable label
    value:     { type: Number, required: true, min: 1, max: 8 },
    companion: { type: mongoose.Schema.Types.Mixed, default: {} },
    verbatim: {
      quote:          { type: String, default: '' },
      interpretation: { type: String, default: '' },
    },
    scoredAt: { type: Date, default: Date.now },
    scoredBy: { type: String, default: 'seed' },
  },
  { timestamps: true }
);

// One value per node per account
nodeSchema.index({ accountId: 1, nodeId: 1 }, { unique: true });

module.exports = mongoose.model('Node', nodeSchema);
